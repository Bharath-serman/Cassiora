
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { toast } from "@/hooks/use-toast";

enum Mode {
  LOGIN,
  SIGNUP,
}

export default function AuthForm() {
  const [mode, setMode] = useState<Mode>(Mode.LOGIN);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);

  const switchMode = () => {
    setMode(mode === Mode.LOGIN ? Mode.SIGNUP : Mode.LOGIN);
    setUsername("");
    setEmail("");
    setPassword("");
  };

  // email redirect for sign up
  const getRedirectUrl = () => `${window.location.origin}/auth`;

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // 1. Sign up in Supabase Auth
    const { error, data } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: getRedirectUrl(),
      }
    });
    if (error) {
      toast({ title: "Signup failed", description: error.message });
      setLoading(false);
      return;
    }
    // Insert or update username in profiles (after confirmation)
    if (data.user) {
      await supabase.from("profiles").upsert({
        id: data.user.id,
        username,
      });
      toast({
        title: "Sign up successful!",
        description: "Please confirm your email before logging in.",
      });
      setMode(Mode.LOGIN);
    }
    setLoading(false);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) {
      toast({ title: "Login failed", description: error.message });
    }
    setLoading(false);
  };

  return (
    <div className="bg-white dark:bg-zinc-900 p-8 max-w-md w-full rounded-lg mx-auto mt-12 shadow border flex flex-col gap-6">
      <h2 className="text-2xl font-bold mb-2">{mode === Mode.LOGIN ? "Sign in" : "Sign up"}</h2>
      <form onSubmit={mode === Mode.LOGIN ? handleLogin : handleSignUp} className="flex flex-col gap-4">
        {mode === Mode.SIGNUP && (
          <Input
            type="text"
            placeholder="Username"
            value={username}
            maxLength={24}
            required
            autoFocus
            onChange={(e) => setUsername(e.target.value)}
          />
        )}
        <Input
          type="email"
          placeholder="Email"
          value={email}
          required
          autoComplete="email"
          onChange={(e) => setEmail(e.target.value)}
        />
        <Input
          type="password"
          placeholder="Password"
          value={password}
          minLength={6}
          required
          autoComplete={mode === Mode.LOGIN ? "current-password" : "new-password"}
          onChange={(e) => setPassword(e.target.value)}
        />
        <Button type="submit" disabled={loading} className="w-full mt-1">{loading ? "Please wait..." : mode === Mode.LOGIN ? "Login" : "Sign Up"}</Button>
      </form>
      <div className="flex items-center justify-between pt-2">
        <span>
          {mode === Mode.LOGIN ? "Don't have an account?" : "Already have an account?"}{" "}
          <button
            className="text-primary underline font-semibold"
            onClick={switchMode}
          >
            {mode === Mode.LOGIN ? "Sign Up" : "Login"}
          </button>
        </span>
      </div>
    </div>
  );
}
