
import { useUser } from "@/components/UserContext";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "react-router-dom";
import { useState } from "react";
import { Settings } from "lucide-react";
import SettingsModal from "./SettingsModal";

export default function Navbar() {
  const { profile, loading } = useUser();
  const [showSettings, setShowSettings] = useState(false);
  const location = useLocation();

  return (
    <>
      <nav className="flex items-center justify-between w-full py-4 px-6 border-b bg-background shadow-sm">
        <Link to="/" className="font-bold text-xl tracking-tight text-primary">
          Placement Prep Powerhouse
        </Link>
        <div className="flex items-center gap-2">
          {/* DSA Visualizer link */}
          <Link to="/dsa-visualizer">
            <Button
              variant={location.pathname === "/dsa-visualizer" ? "default" : "outline"}
              size="sm"
            >
              DSA Visualizer
            </Button>
          </Link>
          {/* Notepad link for signed-in users */}
          {!loading && profile && (
            <Link to="/notepad">
              <Button
                variant={location.pathname === "/notepad" ? "default" : "outline"}
                size="sm"
              >
                Notepad
              </Button>
            </Link>
          )}

          {loading ? null : profile ? (
            <>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Settings"
                onClick={() => setShowSettings(true)}
              >
                <Settings className="w-5 h-5" />
              </Button>
              <span className="font-medium text-base text-muted-foreground">
                👋 {profile.username || profile.email}
              </span>
              {/* Logout button is removed from here */}
            </>
          ) : (
            <Link to="/auth">
              <Button variant="outline" size="sm">Sign in</Button>
            </Link>
          )}
        </div>
      </nav>
      <SettingsModal open={showSettings} onOpenChange={setShowSettings} />
    </>
  );
}

