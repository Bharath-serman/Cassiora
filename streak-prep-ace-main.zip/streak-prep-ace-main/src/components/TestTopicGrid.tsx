
import { cn } from "@/lib/utils";

const topics = [
  {
    key: "dsa",
    label: "DSA",
    desc: "Data Structures & Algorithms",
    color: "from-indigo-500 to-blue-500",
    icon: "📚",
  },
  {
    key: "ml",
    label: "ML",
    desc: "Machine Learning",
    color: "from-green-500 to-emerald-400",
    icon: "🤖",
  },
  {
    key: "ai",
    label: "AI",
    desc: "Artificial Intelligence",
    color: "from-pink-500 to-fuchsia-500",
    icon: "🧠",
  },
  {
    key: "quant",
    label: "Quant",
    desc: "Quantitative Aptitude",
    color: "from-yellow-400 to-yellow-500",
    icon: "🧮",
  },
  {
    key: "lr",
    label: "Logical Reasoning",
    desc: "Logic & Patterns",
    color: "from-cyan-500 to-sky-500",
    icon: "🔗",
  },
  {
    key: "verbal",
    label: "Verbal",
    desc: "Verbal Ability",
    color: "from-purple-500 to-indigo-700",
    icon: "🗣️",
  },
  {
    key: "comm",
    label: "Comm",
    desc: "Communication Skills",
    color: "from-orange-400 to-amber-500",
    icon: "💬",
  },
];

type TestTopicGridProps = {
  onTopicSelect: (key: string) => void;
};

export default function TestTopicGrid({ onTopicSelect }: TestTopicGridProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-4 py-2">
      {topics.map((topic) => (
        <button
          key={topic.key}
          className={cn(
            "flex flex-col items-center justify-between p-4 rounded-xl shadow-md text-white transition-all duration-200 hover:scale-105 hover:ring-2 hover:ring-accent cursor-pointer focus-visible:outline-none min-h-[124px]",
            `bg-gradient-to-br ${topic.color} group`
          )}
          onClick={() => onTopicSelect(topic.key)}
          aria-label={"Pick topic: " + topic.label}
        >
          <div className="text-3xl mb-2 group-hover:scale-125 transition-transform">{topic.icon}</div>
          <span className="font-bold text-lg">{topic.label}</span>
          <span className="text-xs text-white/80">{topic.desc}</span>
        </button>
      ))}
    </div>
  );
}
