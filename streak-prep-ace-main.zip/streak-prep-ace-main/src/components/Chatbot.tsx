
import { useState, useRef, useEffect } from "react";
import { MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";

type ChatMessage = {
  type: "user" | "bot";
  message: string;
};

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 250);
    }
  }, [open]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    setMessages((prev) => [...prev, { type: "user", message: input }]);
    setBusy(true);
    setInput("");
    // TODO: Replace with OpenRouter backend integration
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          type: "bot",
          message:
            "🤖 I'm your AI assistant. (The backend is not connected yet, but I'll help answer queries and explain concepts once the connection is live!)",
        },
      ]);
      setBusy(false);
    }, 1000);
  };

  return (
    <>
      <button
        className="fixed bottom-6 right-6 z-40 rounded-full bg-primary text-white p-0.5 shadow-lg hover:scale-105 transition-transform"
        aria-label="Open AI Assistant Chat"
        onClick={() => setOpen((o) => !o)}
      >
        <MessageSquare className="w-9 h-9 p-1" />
      </button>
      <div
        className={cn(
          "fixed bottom-20 right-6 z-50 w-80 bg-card border rounded-xl shadow-lg p-3 flex flex-col transition-all duration-200",
          open
            ? "opacity-100 visible translate-y-0"
            : "opacity-0 pointer-events-none translate-y-6"
        )}
        style={{ minHeight: 320, maxHeight: 440 }}
      >
        <div className="font-bold text-base mb-2 text-primary flex items-center gap-1">
          AI Assistant
          <span className="ml-1 text-yellow-500 font-extrabold animate-pulse">●</span>
        </div>
        <div
          className="flex-1 overflow-y-auto border rounded-lg mb-2 px-2 py-2 bg-muted/70"
          style={{ minHeight: 180, maxHeight: 220 }}
        >
          {messages.length === 0 && (
            <div className="text-center text-xs text-muted-foreground">
              Ask me anything about interview prep, DSA, ML, or general concepts!
            </div>
          )}
          {messages.map((msg, i) => (
            <div
              key={i}
              className={cn(
                "my-1 px-2 py-1 rounded max-w-[86%] whitespace-pre-line",
                msg.type === "user"
                  ? "bg-primary/80 text-white ml-auto"
                  : "bg-secondary text-accent-foreground mr-auto"
              )}
            >
              {msg.message}
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
        <div className="flex">
          <input
            type="text"
            ref={inputRef}
            value={input}
            disabled={busy}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleSend();
            }}
            className="flex-1 rounded-l-lg border border-border p-2 bg-background"
            placeholder="Type your question..."
            autoFocus={open}
          />
          <button
            onClick={handleSend}
            disabled={busy || !input.trim()}
            className="rounded-r-lg bg-primary text-white px-4 py-2 hover:bg-accent disabled:bg-muted disabled:text-muted-foreground font-bold transition"
          >
            Send
          </button>
        </div>
      </div>
    </>
  );
}
