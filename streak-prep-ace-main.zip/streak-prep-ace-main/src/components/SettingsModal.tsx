
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useTheme } from "next-themes";
import { Sun, Moon, User, Image, LogOut } from "lucide-react";
import { useUser } from "@/components/UserContext";
import { useState } from "react";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface SettingsModalProps {
  open: boolean;
  onOpenChange: (val: boolean) => void;
}

export default function SettingsModal({ open, onOpenChange }: SettingsModalProps) {
  const { profile, refresh, logout } = useUser();
  const { theme, setTheme } = useTheme();
  const [username, setUsername] = useState(profile?.username || "");
  const [email, setEmail] = useState(profile?.email || "");
  const [loading, setLoading] = useState(false);
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);

  // For demo purposes, profile photo upload is simulated.
  // You may integrate Supabase Storage for real upload.

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // For demo: update username/email in profiles table
    const updates: any = {};
    if (username !== profile?.username) updates.username = username;
    // No email update allowed unless you handle Auth
    // But let's display toast and fake-save username
    if (Object.keys(updates).length) {
      const { error } = await supabase
        .from("profiles")
        .update(updates)
        .eq("id", profile?.id);
      if (error) {
        toast({ title: "Failed to update", description: error.message });
      } else {
        toast({ title: "Profile updated", description: "Your profile was updated." });
        refresh();
      }
    }
    setLoading(false);
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // For demo: just show preview. Integrate Supabase Storage for real upload.
      const url = URL.createObjectURL(file);
      setPhotoUrl(url);
      toast({ title: "Profile photo changed (preview only)" });
      // Here: upload to supabase storage then update profile.photo_url in db, then refresh user.
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg w-full">
        <DialogHeader>
          <DialogTitle>
            <span className="flex items-center gap-2">
              <User className="w-5 h-5" /> Settings
            </span>
          </DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="theme" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-4">
            <TabsTrigger value="theme">
              <Sun className="w-4 h-4 mr-1" />
              Theme
            </TabsTrigger>
            <TabsTrigger value="profile">
              <User className="w-4 h-4 mr-1" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="photo">
              <Image className="w-4 h-4 mr-1" />
              Photo
            </TabsTrigger>
            <TabsTrigger value="logout">
              <LogOut className="w-4 h-4 mr-1" />
              Logout
            </TabsTrigger>
          </TabsList>

          {/* Theme Section */}
          <TabsContent value="theme">
            <div className="flex items-center gap-6 justify-center">
              <Button
                variant={theme === "light" ? "secondary" : "ghost"}
                onClick={() => setTheme("light")}
                className="flex items-center gap-2"
              >
                <Sun className="w-5 h-5" />
                Light
              </Button>
              <Button
                variant={theme === "dark" ? "secondary" : "ghost"}
                onClick={() => setTheme("dark")}
                className="flex items-center gap-2"
              >
                <Moon className="w-5 h-5" />
                Dark
              </Button>
              <Button
                variant={!theme || theme === "system" ? "secondary" : "ghost"}
                onClick={() => setTheme("system")}
                className="flex items-center gap-2"
              >
                <Sun className="w-5 h-5" />
                <Moon className="w-5 h-5 -ml-2" />
                System
              </Button>
            </div>
          </TabsContent>

          {/* Profile Section */}
          <TabsContent value="profile">
            <form onSubmit={handleProfileUpdate} className="space-y-2">
              <div>
                <label className="text-sm font-medium mb-1 block">
                  Username
                </label>
                <input
                  className="border rounded px-3 py-2 w-full"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">
                  Email
                </label>
                <input
                  className="border rounded px-3 py-2 w-full bg-gray-100"
                  value={email}
                  disabled
                />
                <span className="text-xs text-muted-foreground ml-1">Cannot be changed</span>
              </div>
              <Button type="submit" variant="default" disabled={loading}>Save</Button>
            </form>
          </TabsContent>

          {/* Profile Photo Upload Section */}
          <TabsContent value="photo">
            <div className="flex flex-col items-center gap-4">
              <Avatar className="w-24 h-24">
                <AvatarImage src={photoUrl || "/placeholder.svg"} alt="Profile" />
                <AvatarFallback>
                  {profile?.username?.[0]?.toUpperCase() || profile?.email?.[0]?.toUpperCase() || "U"}
                </AvatarFallback>
              </Avatar>
              <input
                type="file"
                accept="image/*"
                className="block text-sm file:mr-3 file:py-2 file:px-5 file:border-0 file:bg-primary file:text-primary-foreground file:rounded-lg file:cursor-pointer"
                onChange={handlePhotoChange}
              />
              <span className="text-xs text-gray-500">Just for preview – requires real upload integration</span>
            </div>
          </TabsContent>

          {/* Logout Section */}
          <TabsContent value="logout">
            <div className="flex flex-col items-center gap-3 justify-center">
              <LogOut className="w-10 h-10 text-destructive mb-2" />
              <p className="font-semibold">Ready to leave?</p>
              <Button variant="destructive" onClick={logout}>
                Logout
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
