
import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface UserProfile {
  id: string;
  email: string;
  username: string | null;
  streak: number;
  last_streak_date: string | null;
}

interface UserContextType {
  profile: UserProfile | null;
  loading: boolean;
  refresh: () => void;
  logout: () => void;
}

const UserContext = createContext<UserContextType>({
  profile: null,
  loading: true,
  refresh: () => {},
  logout: () => {},
});

export function UserProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // fetch user + profile
  const fetchProfile = async () => {
    setLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (!user) {
      setProfile(null);
      setLoading(false);
      return;
    }
    // Get public.profiles row
    let { data: profileRow } = await supabase
      .from("profiles")
      .select("id, username, streak, last_streak_date")
      .eq("id", user.id)
      .single();
    setProfile({
      id: user.id,
      email: user.email ?? "",
      username: profileRow ? profileRow.username : null,
      streak: profileRow ? profileRow.streak : 0,
      last_streak_date: profileRow ? profileRow.last_streak_date : null,
    });
    setLoading(false);
  };

  useEffect(() => {
    // subscribe to changes
    const { data: listener } = supabase.auth.onAuthStateChange(() => {
      fetchProfile();
    });
    // load initial
    fetchProfile();
    return () => {
      listener.subscription.unsubscribe();
    };
  }, []);

  const logout = async () => {
    await supabase.auth.signOut();
    setProfile(null);
  };

  return (
    <UserContext.Provider value={{ profile, loading, refresh: fetchProfile, logout }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  return useContext(UserContext);
}

