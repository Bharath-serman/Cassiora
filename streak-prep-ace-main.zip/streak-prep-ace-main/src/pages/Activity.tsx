
import { useState, useEffect } from "react";
import { useUser } from "@/components/UserContext";
import StreakHeatmap from "@/components/StreakHeatmap";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { Zap } from "lucide-react";

// Utility to get last N dates as ISO string (YYYY-MM-DD)
function getLastNDates(n = 30): string[] {
  const arr: string[] = [];
  const today = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    arr.push(d.toISOString().slice(0, 10));
  }
  return arr;
}

// Fetch real question_attempts data from Supabase
async function fetchActivity(userId: string): Promise<Record<string, number>> {
  const last30 = getLastNDates(30);
  const { data, error } = await supabase
    .from("question_attempts")
    .select("date, count")
    .eq("user_id", userId)
    .gte("date", last30[0]);
  if (error || !Array.isArray(data)) {
    console.error(error);
    return {};
  }
  const activity: Record<string, number> = {};
  last30.forEach(d => (activity[d] = 0));
  (data as Tables<"question_attempts">[]).forEach((row) => {
    if (row.date && typeof row.count === "number") {
      activity[row.date] = row.count;
    }
  });
  return activity;
}

export default function ActivityPage() {
  const { profile, loading } = useUser();
  const [activityData, setActivityData] = useState<Record<string, number>>({});
  const [loadingData, setLoadingData] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && profile) {
      setLoadingData(true);
      fetchActivity(profile.id).then((data) => {
        setActivityData(data);
        setLoadingData(false);
      });
    }
  }, [loading, profile]);

  if (loading) {
    return <div className="flex justify-center items-center py-10 text-muted-foreground">Loading user...</div>;
  }
  if (!profile) {
    return (
      <div className="flex flex-col gap-4 items-center py-14">
        <div className="text-lg font-semibold text-red-600">You need to be signed in to view your activity.</div>
        <Button onClick={() => navigate("/auth")}>Sign In</Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center w-full min-h-screen py-10 px-3 animate-fade-in">
      <Card className="w-full max-w-xl mx-auto shadow-2xl bg-primary/5 border-primary/20">
        <CardHeader className="flex flex-row items-center gap-3 pb-2 border-b">
          <div className="bg-green-500/10 border border-green-200 rounded-full p-2 mr-2 animate-scale-in flex items-center justify-center">
            <Zap className="text-green-500" size={28} />
          </div>
          <div>
            <CardTitle className="text-primary text-2xl font-bold tracking-tight flex flex-row items-center gap-2">
              Activity Overview
            </CardTitle>
            <div className="text-sm text-muted-foreground font-medium">
              Your progress over the last 30 days
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex flex-col items-center py-8 gap-4">
          {loadingData ? (
            <div className="text-muted-foreground">Loading activity...</div>
          ) : (
            <StreakHeatmap data={activityData} />
          )}
          <Button
            className="w-full mt-6 font-semibold text-base shadow-lg animate-pulse hover:scale-105 transition"
            variant="outline"
            onClick={() => navigate("/")}
          >
            Back Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
