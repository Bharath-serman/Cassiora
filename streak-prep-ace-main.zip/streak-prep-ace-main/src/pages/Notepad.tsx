import { useUser } from "@/components/UserContext";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Trash2, Save, PlusCircle, ArrowLeft } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Link } from "react-router-dom";
import ConfirmDeleteDialog from "@/components/ConfirmDeleteDialog";

type Note = {
  id: string;
  user_id: string;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
};

export default function NotepadPage() {
  const { profile, loading: userLoading } = useUser();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeNote, setActiveNote] = useState<Note | null>(null);
  const [form, setForm] = useState({ title: "", content: "" });
  const [saving, setSaving] = useState(false);
  const [creating, setCreating] = useState(false);
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; noteId: string | null }>({
    open: false,
    noteId: null,
  });

  // Fetch notes on mount or login
  useEffect(() => {
    if (!profile?.id) return;
    setLoading(true);
    supabase
      .from("notes")
      .select("*")
      .order("updated_at", { ascending: false })
      .then(({ data, error }) => {
        if (error) {
          toast({ title: "Unable to load notes", description: error.message });
        }
        setNotes(data || []);
        setLoading(false);
      });
  }, [profile?.id]);

  // Create new note
  const handleCreate = async () => {
    if (!form.title.trim() && !form.content.trim()) {
      toast({ title: "Note empty", description: "Can't save an empty note." });
      return;
    }
    setCreating(true);
    const { data, error } = await supabase
      .from("notes")
      .insert([
        {
          user_id: profile!.id,
          title: form.title,
          content: form.content,
        },
      ])
      .select()
      .maybeSingle();
    setCreating(false);
    if (error) {
      toast({ title: "Failed to save", description: error.message });
    } else if (data) {
      setNotes([data, ...notes]);
      setForm({ title: "", content: "" });
      setActiveNote(data);
      toast({ title: "Note saved!" });
    }
  };

  // Edit note
  const handleEdit = (note: Note) => {
    setActiveNote(note);
    setForm({ title: note.title, content: note.content });
  };

  // Update note
  const handleUpdate = async () => {
    if (!activeNote) return;
    setSaving(true);
    const { data, error } = await supabase
      .from("notes")
      .update({
        title: form.title,
        content: form.content,
        updated_at: new Date().toISOString(),
      })
      .eq("id", activeNote.id)
      .select()
      .maybeSingle();
    setSaving(false);
    if (error) {
      toast({ title: "Failed to update", description: error.message });
    } else if (data) {
      setNotes((prev) =>
        prev.map((n) => (n.id === data.id ? { ...n, ...data } : n))
      );
      setActiveNote(data);
      toast({ title: "Note updated!" });
    }
  };

  // Delete note
  const handleDelete = async (id: string) => {
    setDeleteDialog({ open: false, noteId: null });
    const { error } = await supabase.from("notes").delete().eq("id", id);
    if (error) {
      toast({ title: "Failed to delete", description: error.message });
    } else {
      setNotes((prev) => prev.filter((n) => n.id !== id));
      if (activeNote?.id === id) {
        setActiveNote(null);
        setForm({ title: "", content: "" });
      }
      toast({ title: "Note deleted" });
    }
  };

  const handleCancelEdit = () => {
    setActiveNote(null);
    setForm({ title: "", content: "" });
  };

  if (userLoading) {
    return (
      <div className="flex justify-center p-10">
        <Loader2 className="animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="mx-auto max-w-lg mt-20 border rounded-lg bg-background p-6 flex flex-col items-center gap-5 shadow">
        <h2 className="text-xl font-bold text-primary">Notepad</h2>
        <p className="text-muted-foreground">
          Please <span className="font-semibold">sign in</span> to take notes.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto mt-8 p-6 bg-card/60 rounded-2xl shadow border">
      {/* Back button */}
      <div className="mb-4">
        <Link to="/">
          <Button variant="ghost" size="sm" className="gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
        </Link>
      </div>

      <h1 className="text-2xl font-bold mb-4 text-primary flex items-center gap-2">
        📝 Notepad
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {/* Note list panel */}
        <div className="md:col-span-2">
          <div className="flex justify-between items-center mb-2">
            <span className="font-semibold text-primary">Your Notes</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setActiveNote(null);
                setForm({ title: "", content: "" });
              }}
            >
              <PlusCircle className="mr-1 w-4 h-4" />
              New note
            </Button>
          </div>
          {loading ? (
            <div className="flex justify-center py-8 text-muted-foreground">
              <Loader2 className="animate-spin" />
            </div>
          ) : notes.length === 0 ? (
            <div className="text-muted-foreground text-center mt-6">
              No notes yet. Click "New note" to create one.
            </div>
          ) : (
            <ul className="flex flex-col gap-1">
              {notes.map((note) => (
                <li
                  key={note.id}
                  className={`flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer hover:bg-accent transition-colors ${
                    activeNote?.id === note.id
                      ? "bg-accent border font-semibold border-primary"
                      : "border-transparent"
                  }`}
                  onClick={() => handleEdit(note)}
                >
                  <div>
                    <div className="truncate">{note.title || <i>(untitled)</i>}</div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(note.updated_at).toLocaleString()}
                    </div>
                  </div>
                  <ConfirmDeleteDialog
                    open={deleteDialog.open && deleteDialog.noteId === note.id}
                    onOpenChange={(open) =>
                      setDeleteDialog((prev) => ({
                        open,
                        noteId: open ? note.id : null,
                      }))
                    }
                    onConfirm={() => handleDelete(note.id)}
                    trigger={
                      <Button
                        variant="ghost"
                        size="icon"
                        className="hover:text-red-500"
                        aria-label="Delete"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeleteDialog({ open: true, noteId: note.id });
                        }}
                      >
                        <Trash2 size={16} />
                      </Button>
                    }
                  />
                </li>
              ))}
            </ul>
          )}
        </div>
        {/* Note editor panel */}
        <div className="md:col-span-3 flex flex-col gap-2">
          <Input
            type="text"
            placeholder="Title"
            value={form.title}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            className="text-lg font-bold"
            maxLength={150}
            disabled={saving || creating}
          />
          <Textarea
            className="min-h-[220px] text-base"
            placeholder="Start writing your note..."
            value={form.content}
            onChange={(e) =>
              setForm((f) => ({ ...f, content: e.target.value }))
            }
            maxLength={2000}
            disabled={saving || creating}
          />
          <div className="flex gap-3 mt-2">
            {activeNote ? (
              <>
                <Button
                  onClick={handleUpdate}
                  disabled={saving}
                  className="gap-2"
                >
                  <Save size={18} />
                  {saving ? "Saving..." : "Save changes"}
                </Button>
                <Button
                  variant="secondary"
                  onClick={handleCancelEdit}
                  disabled={saving || creating}
                >
                  Cancel
                </Button>
              </>
            ) : (
              <Button
                onClick={handleCreate}
                disabled={creating || (!form.title.trim() && !form.content.trim())}
                className="gap-2"
              >
                <Save size={18} />
                {creating ? "Creating..." : "Save note"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
