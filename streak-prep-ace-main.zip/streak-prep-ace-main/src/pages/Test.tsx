import { useLocation, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import LoadingSpinner from "./Test/LoadingSpinner";
import TestReady from "./Test/TestReady";
import TestInProgress from "./Test/TestInProgress";
import TestFinished from "./Test/TestFinished";
import { useUser } from "@/components/UserContext";
import SignInOverlay from "@/components/SignInOverlay";

type TestQuestion = {
  question: string;
  options: Record<string, string>;
  answer: string;
  explanation: string;
  company?: string;
};

type Phase = "loading" | "ready" | "in-progress" | "finished";

// Helper function to check streak update logic
function shouldIncrementStreak(lastDateString: string | null) {
  if (!lastDateString) return "start"; // first ever completion
  const today = new Date();
  const lastDate = new Date(lastDateString);
  // Normalize both dates to YYYY-MM-DD strings:
  const todayStr = today.toISOString().slice(0, 10);
  const lastDateStr = lastDate.toISOString().slice(0, 10);
  if (lastDateStr === todayStr) return "already";
  // Is yesterday?
  const yest = new Date(today);
  yest.setDate(today.getDate() - 1);
  const yesterdayStr = yest.toISOString().slice(0, 10);
  if (lastDateStr === yesterdayStr) return "increment";
  return "reset";
}

export default function TestPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { profile, loading, refresh } = useUser();
  const [phase, setPhase] = useState<Phase>("loading");
  const [questions, setQuestions] = useState<TestQuestion[]>([]);
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [score, setScore] = useState(0);

  useEffect(() => {
    // If not loading and not signed in, show overlay (return early)
    if (!loading && !profile) return;
    const state = location.state as { topic?: string };
    if (!state?.topic) {
      toast({ title: "No topic selected.", description: "Please select a topic from the homepage." });
      navigate("/");
      return;
    }
    setSelectedTopic(state.topic);

    // Only fetch questions when phase is not finished
    // Prevent refetching after finishing a test
    if (phase === "finished") return;

    // Fetch/generate questions
    (async () => {
      setPhase("loading");
      try {
        const { data, error } = await supabase.functions.invoke("generate-daily-test", {
          body: { topic: state.topic },
        });
        if (error) throw new Error(error.message || "Error generating questions");
        if (!data?.questions || !Array.isArray(data.questions)) throw new Error("No questions returned from AI");
        setQuestions(data.questions);
        setPhase("ready");
      } catch (err: any) {
        toast({ title: "Failed to load test", description: err?.message });
        setTimeout(() => navigate("/"), 2000);
      }
    })();
    // eslint-disable-next-line
  }, [loading, profile, phase]); // Do not include `phase` dependency to avoid double fetch after finished

  const handleStart = () => {
    setPhase("in-progress");
    setAnswers({});
    setScore(0);
  };

  const handleAnswer = (idx: number, value: string) => {
    setAnswers((prev) => ({ ...prev, [idx]: value }));
  };

  // Helper function to check streak update logic
  function shouldIncrementStreak(lastDateString: string | null) {
    if (!lastDateString) return "start"; // first ever completion
    const today = new Date();
    const lastDate = new Date(lastDateString);
    // Normalize both dates to YYYY-MM-DD strings:
    const todayStr = today.toISOString().slice(0, 10);
    const lastDateStr = lastDate.toISOString().slice(0, 10);
    if (lastDateStr === todayStr) return "already";
    // Is yesterday?
    const yest = new Date(today);
    yest.setDate(today.getDate() - 1);
    const yesterdayStr = yest.toISOString().slice(0, 10);
    if (lastDateStr === yesterdayStr) return "increment";
    return "reset";
  }

  // Updated: always refresh user profile after updating streak
  const handleStreakUpdate = async () => {
    if (!profile) return;
    const userId = profile.id;

    // Get latest profile from DB to prevent race conditions
    const { data: profileRow, error } = await supabase
      .from("profiles")
      .select("streak, last_streak_date")
      .eq("id", userId)
      .maybeSingle();

    if (error) {
      toast({ title: "Error updating streak", description: error.message });
      return;
    }
    const streak = profileRow?.streak ?? 0;
    const last_streak_date = profileRow?.last_streak_date ?? null;

    const streakAction = shouldIncrementStreak(last_streak_date);

    let newStreak = 1;
    if (streakAction === "already") {
      // But still force refresh—in case user has logged in elsewhere
      refresh?.();
      return;
    } else if (streakAction === "increment") {
      newStreak = streak + 1;
    } else if (streakAction === "reset") {
      newStreak = 1;
    }
    // Set today's date string
    const nowDateStr = new Date().toISOString().slice(0, 10);
    const { error: updateErr } = await supabase
      .from("profiles")
      .update({ streak: newStreak, last_streak_date: nowDateStr })
      .eq("id", userId);

    // Always refresh
    await refresh?.();
    if (updateErr) {
      toast({ title: "Failed to update streak", description: updateErr.message });
    }
    if (streakAction === "increment" || streakAction === "start") {
      toast({
        title: "🔥 Streak increased!",
        description: `You are on a ${newStreak}-day streak! Great job!`,
      });
    } else if (streakAction === "reset") {
      toast({
        title: "Streak reset",
        description: "Streak started again from today. Keep going!",
      });
    }
  };

  // Updated: force profile refresh before navigating home
  const handleGoHome = async () => {
    await refresh?.(); // Ensure profile is up-to-date for home
    navigate("/");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    let total = 0;
    questions.forEach((q, i) => {
      if (answers[i] === q.answer) total++;
    });
    setScore(total);
    // Update streak
    await handleStreakUpdate();
    setPhase("finished");
  };

  // Show the sign in overlay if user is not signed in and not loading
  if (!loading && !profile) {
    return <SignInOverlay />;
  }

  if (phase === "loading") return <LoadingSpinner />;

  if (!questions.length) {
    return (
      <div className="flex flex-col items-center py-10">
        <div className="font-bold text-lg mb-1">No questions found.</div>
        <Button onClick={() => navigate("/")}>Go Home</Button>
      </div>
    );
  }

  return (
    <div className="w-full min-h-screen max-w-2xl mx-auto px-4 py-12 flex flex-col items-center gap-8">
      <div className="flex flex-col gap-2 items-center">
        <h1 className="text-2xl font-bold text-primary">
          AI Test: {selectedTopic.toUpperCase()}
        </h1>
        {profile && (
          <div className="flex flex-row gap-2 items-center mt-2">
            <span className="text-xl">🔥</span>
            <span className="font-bold text-xl tracking-wide text-green-600">{profile.streak}</span>
            <span className="text-base text-muted-foreground ml-1">day streak</span>
          </div>
        )}
      </div>
      {phase === "ready" && (
        <TestReady
          questionsLength={questions.length}
          onStart={handleStart}
        />
      )}
      {phase === "in-progress" && (
        <TestInProgress
          questions={questions}
          answers={answers}
          onAnswer={handleAnswer}
          onSubmit={handleSubmit}
        />
      )}
      {phase === "finished" && (
        <TestFinished
          questions={questions}
          answers={answers}
          score={score}
          onGoHome={handleGoHome}
        />
      )}
    </div>
  );
}
