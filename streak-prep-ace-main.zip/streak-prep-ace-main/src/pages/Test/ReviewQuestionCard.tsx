
type TestQuestion = {
  question: string;
  options: Record<string, string>;
  answer: string;
  explanation: string;
  company?: string;
};

interface ReviewQuestionCardProps {
  idx: number;
  question: TestQuestion;
  userAnswer: string;
}

const ReviewQuestionCard = ({ idx, question, userAnswer }: ReviewQuestionCardProps) => {
  const isCorrect = userAnswer === question.answer;
  return (
    <div
      className={
        "p-3 md:p-5 rounded-xl border shadow transition " +
        (isCorrect
          ? "bg-green-50 dark:bg-green-900/30 border-green-400"
          : "bg-red-50 dark:bg-red-900/30 border-red-400")
      }
    >
      <div className="font-semibold mb-1 text-base md:text-lg">
        Q{idx + 1}: <span className="whitespace-pre-line">{question.question}</span>
      </div>
      <div className="mb-2 flex flex-col gap-1">
        {Object.entries(question.options).map(([opt, text]) => (
          <div
            key={opt}
            className={
              "flex items-center gap-2 px-2 py-1 rounded transition " +
              (question.answer === opt
                ? "bg-green-200 dark:bg-green-900/60 font-bold"
                : userAnswer === opt
                  ? "bg-red-200 dark:bg-red-900/40"
                  : "bg-card")
            }
          >
            <span className="w-7 font-bold uppercase text-sm md:text-base">{opt}.</span>
            <span className="text-sm md:text-base">{text}</span>
            {userAnswer === opt && (
              <span className="ml-1 text-xs">
                {isCorrect && opt === question.answer
                  ? "Your Answer (Correct)"
                  : !isCorrect && opt === userAnswer
                  ? "Your Answer"
                  : ""}
              </span>
            )}
            {opt === question.answer && (
              <span className="ml-1 text-xs text-green-700 dark:text-green-300">Correct</span>
            )}
          </div>
        ))}
      </div>
      <div className="text-sm text-muted-foreground italic">
        Explanation: {question.explanation || "No explanation provided."}
      </div>
      <div className="text-xs text-blue-700 dark:text-blue-300 mt-2">
        {question.company
          ? `Company that asked this: ${question.company}`
          : "Company: [Not specified]"}
      </div>
    </div>
  );
};
export default ReviewQuestionCard;
