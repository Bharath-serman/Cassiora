
import { Button } from "@/components/ui/button";
import QuestionCard from "./QuestionCard";

type TestQuestion = {
  question: string;
  options: Record<string, string>;
  answer: string;
  explanation: string;
  company?: string;
};

interface TestInProgressProps {
  questions: TestQuestion[];
  answers: Record<number, string>;
  onAnswer: (idx: number, value: string) => void;
  onSubmit: (e: React.FormEvent) => void;
}

const TestInProgress = ({
  questions,
  answers,
  onAnswer,
  onSubmit
}: TestInProgressProps) => (
  <form
    onSubmit={onSubmit}
    className="flex flex-col gap-6 w-full max-w-3xl mx-auto"
  >
    {questions.map((q, idx) => (
      <QuestionCard
        key={idx}
        idx={idx}
        question={q}
        value={answers[idx] || ""}
        onChange={val => onAnswer(idx, val)}
      />
    ))}
    <Button
      type="submit"
      className="self-end mt-2"
      disabled={Object.keys(answers).length !== questions.length}
    >
      Submit Test
    </Button>
  </form>
);

export default TestInProgress;
