
import { Button } from "@/components/ui/button";

interface TestReadyProps {
  questionsLength: number;
  onStart: () => void;
}

const TestReady = ({ questionsLength, onStart }: TestReadyProps) => (
  <div className="flex flex-col items-center gap-6 bg-muted px-6 sm:px-8 py-9 rounded-xl border max-w-lg w-full">
    <div className="text-base sm:text-lg font-medium mb-3">You have {questionsLength} questions. Good luck!</div>
    <Button className="w-40 sm:w-44" onClick={onStart}>Start Test</Button>
  </div>
);

export default TestReady;
