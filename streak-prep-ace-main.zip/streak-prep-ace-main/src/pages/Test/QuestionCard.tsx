import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

type TestQuestion = {
  question: string;
  options: Record<string, string>;
  answer: string;
  explanation: string;
  company?: string;
};

interface QuestionCardProps {
  idx: number;
  question: TestQuestion;
  value: string;
  onChange: (value: string) => void;
}

const QuestionCard = ({ idx, question, value, onChange }: QuestionCardProps) => (
  <div className="p-4 sm:p-6 rounded-lg border shadow bg-card border-card transition-all w-full max-w-3xl mx-auto">
    <div className="font-semibold mb-2 text-base md:text-lg">
      Q{idx + 1}: <span className="whitespace-pre-line">{question.question}</span>
    </div>
    <RadioGroup value={value} onValueChange={onChange} className="gap-3">
      {Object.entries(question.options || {}).map(([opt, val]) => (
        <label
          key={opt}
          className={
            "flex items-center gap-2 py-1 rounded px-2 cursor-pointer transition " +
            (value === opt
              ? "bg-primary/10 font-semibold"
              : "hover:bg-accent/30")
          }
        >
          <RadioGroupItem value={opt} id={`q${idx}_${opt}`} />
          <span className="w-7 font-bold uppercase text-sm md:text-base">{opt}.</span>
          <span className="text-sm md:text-base">{val}</span>
        </label>
      ))}
    </RadioGroup>
  </div>
);

export default QuestionCard;
