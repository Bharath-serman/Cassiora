
import { Button } from "@/components/ui/button";
import ReviewQuestionCard from "./ReviewQuestionCard";

type TestQuestion = {
  question: string;
  options: Record<string, string>;
  answer: string;
  explanation: string;
  company?: string;
};

interface TestFinishedProps {
  questions: TestQuestion[];
  answers: Record<number, string>;
  score: number;
  onGoHome: () => void;
}

const TestFinished = ({ questions, answers, score, onGoHome }: TestFinishedProps) => (
  <div className="flex flex-col gap-8 w-full max-w-3xl mx-auto items-center px-1">
    <div className="font-bold text-xl md:text-2xl text-center text-primary">
      Your Score: {score} / {questions.length}
    </div>
    <div className="flex flex-col gap-5 w-full">
      {questions.map((q, idx) => (
        <ReviewQuestionCard
          key={idx}
          idx={idx}
          question={q}
          userAnswer={answers[idx] || ""}
        />
      ))}
    </div>
    <Button className="self-end mt-2 w-28" variant="secondary" onClick={onGoHome}>
      Home
    </Button>
  </div>
);

export default TestFinished;
