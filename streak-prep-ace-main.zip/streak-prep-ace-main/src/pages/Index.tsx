import { useState, useEffect } from "react";
import TestTopicGrid from "@/components/TestTopicGrid";
import StreakHeatmap from "@/components/StreakHeatmap";
import StreakCounter from "@/components/StreakCounter";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { useUser } from "@/components/UserContext";
import { useIsMobile } from "@/hooks/use-mobile";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import FeedbackForm from "@/components/FeedbackForm";

// Utility to get last N dates as ISO string (YYYY-MM-DD)
function getLastNDates(n = 30): string[] {
  const arr: string[] = [];
  const today = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    arr.push(d.toISOString().slice(0, 10));
  }
  return arr;
}

async function fetchActivity(userId: string): Promise<Record<string, number>> {
  const last30 = getLastNDates(30);
  const { data, error } = await supabase
    .from("question_attempts")
    .select("date, count")
    .eq("user_id", userId)
    .gte("date", last30[0]);
  if (error || !Array.isArray(data)) {
    console.error(error);
    return {};
  }
  const activity: Record<string, number> = {};
  // Default every day to 0
  last30.forEach(d => (activity[d] = 0));
  (data as Tables<"question_attempts">[]).forEach((row) => {
    if (row.date && typeof row.count === "number") {
      activity[row.date] = row.count;
    }
  });
  return activity;
}

export default function Index() {
  const { profile, loading } = useUser();
  const [activityData, setActivityData] = useState<Record<string, number>>({});
  const [loadingData, setLoadingData] = useState(true);
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  useEffect(() => {
    if (!loading && profile) {
      setLoadingData(true);
      fetchActivity(profile.id).then((data) => {
        setActivityData(data);
        setLoadingData(false);
      });
    }
  }, [loading, profile]);

  const handleTopicSelect = (topic: string) => {
    navigate("/test", { state: { topic } });
  };

  return (
    <div className="w-full min-h-screen max-w-7xl mx-auto px-4 sm:px-4 md:px-8 py-6 md:py-10 flex flex-col gap-8 md:gap-10 animate-fade-in">
      {/* Navbar/user */}
      <div className="flex flex-col gap-2 items-center mb-2">
        {loading ? (
          <span className="text-base text-muted-foreground">Loading user...</span>
        ) : profile ? (
          <span className="text-xl font-semibold text-primary text-center break-all">
            Welcome, {profile.username || profile.email}!
          </span>
        ) : (
          <span className="text-base text-muted-foreground text-center">Welcome! Please sign in to personalize your experience.</span>
        )}
      </div>
      {/* Headline and streak */}
      <div className="w-full flex flex-col md:flex-row items-center justify-between gap-6 mb-4 md:mb-7">
        <div className="flex flex-col gap-1 items-start md:items-start w-full md:w-fit">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary tracking-tight text-left mb-1">
            Placement Prep Powerhouse <span role="img" aria-label="Rocket">🚀</span>
          </h1>
          <span className="text-lg md:text-xl font-medium text-muted-foreground text-left">
            Master interviews with daily, AI-curated mock tests &amp; gamified progress.
          </span>
        </div>
        <div className="flex justify-center md:justify-end w-full md:w-fit flex-shrink-0">
          <StreakCounter streak={profile?.streak ?? 0} />
        </div>
      </div>
      {/* Main grid: topics + streak/activity */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-8 md:gap-14 w-full">
        <div>
          <h2 className="font-bold text-lg sm:text-xl mb-3">Pick Today’s Test Topic</h2>
          <TestTopicGrid onTopicSelect={handleTopicSelect} />
        </div>
        <div className="flex flex-col items-center gap-6 min-w-0 w-full">
          <div className="w-full">
            {loading || loadingData || !profile ? (
              <div className="text-center text-muted-foreground py-4">Loading activity...</div>
            ) : (
              <StreakHeatmap data={activityData} />
            )}
          </div>
          <Button
            className="w-full mt-2"
            variant="outline"
            onClick={() => navigate("/activity")}
          >
            View Full Activity
          </Button>
        </div>
      </div>
      <div className="flex flex-col items-center bg-gradient-to-r from-indigo-100 to-blue-50 dark:from-indigo-900 dark:to-blue-950 rounded-xl py-6 sm:py-8 px-4 sm:px-12 mt-8 shadow border border-primary/20 w-full max-w-2xl mx-auto">
        {/* --- STREAK ALIVE CTA --- */}
        <span className="text-xl sm:text-2xl mb-2 font-bold text-primary text-center">Keep Your Streak Alive!</span>
        <span className="text-md sm:text-lg text-muted-foreground mb-3 text-center">Complete your daily test to progress and unlock new achievement badges.</span>
        <button
          className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-base font-bold px-7 py-2 rounded-full shadow hover:scale-105 transition"
          onClick={() => {
            Notification.requestPermission().then((perm) => {
              if (perm === "granted") {
                new Notification("Time to keep your streak alive!", {
                  body: "Jump in and complete your daily test for a new badge 🏅",
                  icon: "/favicon.ico",
                });
              } else {
                toast({
                  title: "Notifications disabled",
                  description: "Enable browser notifications to get daily streak reminders.",
                });
              }
            });
          }}
        >
          Enable Motivational Notifications
        </button>
      </div>
      {/* --- FEEDBACK FORM FOOTER --- */}
      <footer className="w-full mt-10 flex flex-col items-center py-8 px-2 gap-2 bg-card/60 rounded-xl">
        <FeedbackForm />
        <p className="text-xs text-muted-foreground mt-2 text-center">
          Got suggestions, problems, or praise? We'd love to hear from you!
        </p>
      </footer>
    </div>
  );
}
