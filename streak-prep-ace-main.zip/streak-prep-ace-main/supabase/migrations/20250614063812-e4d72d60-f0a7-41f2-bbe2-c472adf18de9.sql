
-- Create a table for user profiles (id = auth.users.id, plus username)
CREATE TABLE public.profiles (
  id UUID NOT NULL PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Policy: users can select their own profile
CREATE POLICY "Users can select their profile" ON public.profiles
  FOR SELECT
  USING (auth.uid() = id);

-- Policy: users can update their own profile
CREATE POLICY "Users can update their profile" ON public.profiles
  FOR UPDATE
  USING (auth.uid() = id);

-- Policy: users can insert their own profile
CREATE POLICY "Users can insert their profile" ON public.profiles
  FOR INSERT
  WITH CHECK (auth.uid() = id);
