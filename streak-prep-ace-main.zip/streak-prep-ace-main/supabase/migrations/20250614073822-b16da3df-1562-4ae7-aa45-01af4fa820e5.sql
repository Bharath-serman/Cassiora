
-- Add streak and last_streak_date to profiles table
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS streak integer NOT NULL DEFAULT 0;

ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS last_streak_date date;
