
-- Table for tracking user activity per day (number of questions attempted)
CREATE TABLE public.question_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  UNIQUE (user_id, date)
);

-- Enable Row Level Security
ALTER TABLE public.question_attempts ENABLE ROW LEVEL SECURITY;

-- Allow users to select their own question attempts
CREATE POLICY "Users can select own attempt activity" ON public.question_attempts
  FOR SELECT
  USING (auth.uid() = user_id);

-- Allow users to insert attempts for themself
CREATE POLICY "Users can insert own attempt activity" ON public.question_attempts
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Allow users to update only their own attempts
CREATE POLICY "Users can update own attempt activity" ON public.question_attempts
  FOR UPDATE
  USING (auth.uid() = user_id);

-- (Optional) Allow deleting own activity
CREATE POLICY "Users can delete own attempt activity" ON public.question_attempts
  FOR DELETE
  USING (auth.uid() = user_id);
