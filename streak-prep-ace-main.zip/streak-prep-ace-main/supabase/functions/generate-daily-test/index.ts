
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const TOPIC_PROMPTS: Record<string, string> = {
  dsa: "Data Structures and Algorithms",
  ml: "Machine Learning",
  ai: "Artificial Intelligence",
  quant: "Quantitative Aptitude",
  lr: "Logical Reasoning",
  verbal: "Verbal Ability",
  comm: "Communication Skills",
};

const OPENROUTER_API_KEY = Deno.env.get("OPENROUTER_API_KEY");
console.log("[Edge] Loaded OPENROUTER_API_KEY: ", OPENROUTER_API_KEY ? "Loaded" : "Missing");

// Start the server
serve(async (req: Request) => {
  console.log("[Edge] Received request", req.method, req.url);

  if (req.method === "OPTIONS") {
    console.log("[Edge] Handling CORS preflight");
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const bodyRaw = await req.text();
    console.log("[Edge] Raw request body:", bodyRaw);

    let bodyData: any;
    try {
      bodyData = JSON.parse(bodyRaw);
    } catch (err) {
      console.error("[Edge] Failed to parse request body as JSON:", err);
      return new Response(JSON.stringify({ error: "Invalid JSON in request body" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { topic } = bodyData || {};
    console.log("[Edge] Parsed topic:", topic);

    if (!topic || !TOPIC_PROMPTS[topic]) {
      console.error("[Edge] Invalid or missing topic:", topic);
      return new Response(JSON.stringify({ error: "Invalid or missing topic" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!OPENROUTER_API_KEY) {
      console.error("[Edge] OPENROUTER_API_KEY missing");
      return new Response(JSON.stringify({ error: "OPENROUTER_API_KEY missing in environment" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = `Generate 5 unique, interview-style multiple choice questions on the topic of "${TOPIC_PROMPTS[topic]}". Each question must be returned as JSON and include ALL of the following keys:
- question (string)
- options (object with keys a,b,c,d)
- answer (string; correct key a/b/c/d)
- explanation (string; max 2 lines)
- company (string; name of a real company who has asked this question e.g., "Amazon", "Google", "Meta", or "Not specified" if not known)

Return the result as an array, no extra text. Example format:
[
  {
    "question": "What is ...?",
    "options": { "a": "...", "b": "...", "c": "...", "d": "..." },
    "answer": "a",
    "explanation": "...",
    "company": "Amazon"
  },
  ...
]`;

    // Call OpenRouter API
    console.log("[Edge] Calling OpenRouter API...");
    const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "deepseek/deepseek-r1:free",
        messages: [
          {
            role: "system",
            content: "You are an expert placement test creator. Respond ONLY with valid JSON as specified.",
          },
          {
            role: "user",
            content: prompt,
          }
        ],
        max_tokens: 2000,
        temperature: 0.6
      }),
    });

    console.log("[Edge] OpenRouter API response status:", res.status);

    if (!res.ok) {
      const err = await res.text();
      console.error("[Edge] OpenRouter fetch failed:", err);
      return new Response(JSON.stringify({ error: "Failed to fetch from OpenRouter: " + err }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const openrouterData = await res.json();
    console.log("[Edge] OpenRouter data:", JSON.stringify(openrouterData).slice(0, 500)); // Limit log size

    const modelContent = openrouterData.choices?.[0]?.message?.content ?? "";
    console.log("[Edge] Model response content:", modelContent.slice(0, 500)); // Truncate for log

    let questions = null;
    try {
      questions = JSON.parse(modelContent);
      console.log("[Edge] Parsed questions as valid JSON array.");
    } catch {
      // Try to extract just the JSON if model included extra text
      const jsonMatch = modelContent.match(/\[[\s\S]*?\]/);
      if (jsonMatch) {
        try {
          questions = JSON.parse(jsonMatch[0]);
          console.log("[Edge] Extracted questions array from model text.");
        } catch {
          questions = null;
          console.error("[Edge] JSON parse failed after extracting array.");
        }
      } else {
        console.error("[Edge] No JSON array found in model content.");
      }
    }

    if (!Array.isArray(questions) || questions.length === 0) {
      console.error("[Edge] AI did not return valid questions", { modelContent });
      return new Response(JSON.stringify({ error: "AI did not return valid questions", raw: modelContent }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log("[Edge] Returning questions successfully.");
    return new Response(JSON.stringify({ questions }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (e: any) {
    console.error("[Edge] Unexpected error:", e?.message, e);
    return new Response(JSON.stringify({ error: e?.message ?? "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

